// src/hooks/useThemes.ts
import { useQuery } from "@tanstack/react-query";
import type { Theme } from "@/api/types";
import { getTheme, getThemes, getThemesByUser } from "@/api/themes";
import useMe from "./useMe";

// 테마 목록을 최신 생성일 순으로 정렬
function sortByLatest(themes: Theme[]) {
  return [...themes].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

// 내가 만든 테마 목록(최신순) 조회 훅
export function useMyThemes() {
  const { data: me } = useMe();
  const publicUserId = me?.public_user_id ?? "";

  return useQuery({
    queryKey: ["themes", "user", publicUserId],
    // 내 테마 목록 요청
    queryFn: () => getThemesByUser(publicUserId),
    enabled: publicUserId !== "",
    select: sortByLatest,
  });
}

// 공개된 전체 테마 목록(최신순) 조회 훅
export function useAllThemes() {
  return useQuery({
    queryKey: ["themes", "all"],
    // 전체 테마 목록 요청
    queryFn: () => getThemes(),
    // 비공개 테마를 제외하고 최신순으로 정렬
    select: (themes) => sortByLatest(themes.filter((theme) => theme.isPublic)),
  });
}

// 테마 한 건 조회 훅
export function useTheme(themeId?: number) {
  return useQuery({
    queryKey: ["themes", "detail", themeId],
    // 테마 한 건 요청
    queryFn: () => getTheme(themeId as number),
    enabled: themeId !== undefined,
  });
}
