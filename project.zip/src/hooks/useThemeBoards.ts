// src/hooks/useThemeBoards.ts
import { useInfiniteQuery, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createThemeBoard, getThemeBoard, getThemeBoards } from "@/api/themeBoards";
import type { ThemeBoardCreate } from "@/api/types";

const PAGE_SIZE = 18;

// 테마 게시글 목록(검색어, 더 불러오기) 조회 훅
export function useThemeBoardList(keyword: string) {
  return useInfiniteQuery({
    queryKey: ["theme-boards", keyword],
    // 페이지 단위로 테마 게시글 목록 요청
    queryFn: ({ pageParam }) =>
      getThemeBoards({ keyword: keyword || undefined, page: pageParam, size: PAGE_SIZE }),
    initialPageParam: 0,
    // 마지막 페이지가 가득 찼으면 다음 페이지 번호 반환
    getNextPageParam: (lastPage, allPages) =>
      lastPage.length === PAGE_SIZE ? allPages.length : undefined,
  });
}

// 테마 게시글 상세 조회 훅
export function useThemeBoard(postId?: number) {
  return useQuery({
    queryKey: ["theme-boards", "detail", postId],
    // 게시글 한 건 요청
    queryFn: () => getThemeBoard(postId as number),
    enabled: postId !== undefined,
  });
}

// 테마 게시글 작성 요청 훅
export function useCreateThemeBoard() {
  const queryClient = useQueryClient();

  return useMutation({
    // 게시글 작성 요청 전송
    mutationFn: (boardInfo: ThemeBoardCreate) => createThemeBoard(boardInfo),
    // 작성 후 게시글 목록 캐시 무효화
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["theme-boards"] }),
  });
}
