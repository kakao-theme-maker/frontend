// src/components/theme/customize/screen/PasscodeScreenPreview.tsx
import { CODE_IMAGE_COLUMNS } from "@/config/themeAssets";
import { useThemeStore } from "@/store/customizeStore";
import PreviewBullet from "../preview/PreviewBullet";
import PreviewKeypadNumber from "../preview/PreviewKeypadNumber";

const KEYS = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "", "0", "delete"];

// 잠금화면 프리뷰 컴포넌트
export default function PasscodeScreenPreview() {
  const common = useThemeStore((state) => state.theme.common);
  const passcode = useThemeStore((state) => state.theme.passcode);

  return (
    <div className="relative w-full h-full rounded-2xl items-center justify-center flex flex-col">
      <div className="w-full h-12 rounded-t-2xl" style={{ backgroundColor: passcode.bgColor }} />
      <div
        className="flex-1 w-full flex flex-col items-center justify-center gap-2"
        style={{
          backgroundImage: `url(${passcode.bgImage})`,
          backgroundSize: "cover",
          backgroundRepeat: "no-repeat",
          backgroundPosition: "center",
          color: common.mainTextColor,
        }}
      >
        <p className="text-xl">비밀번호</p>
        <p className="font-thin">카카오톡 암호를 입력해주세요.</p>
        <section className="grid grid-cols-4 gap-2 mt-4">
          {CODE_IMAGE_COLUMNS.map((column, index) => (
            <PreviewBullet
              key={column.key}
              filled={index < 2}
              emptyImage={passcode[column.key]}
              filledImage={passcode[column.selectedKey]}
            />
          ))}
        </section>
      </div>
      <div className="flex w-full h-54 items-center justify-center p-4 rounded-b-2xl" style={{ backgroundColor: passcode.keypadBGColor }}>
        <div className="grid grid-cols-3 gap-x-10">
          {KEYS.map((key, i) => (
            <div key={i} className="relative" style={{ color: passcode.keypadTextColor }}>
              {i === 4 && (
                <img src={passcode.keypadPressed} className="absolute inset-0 w-full h-full object-contain" />
              )}
              <PreviewKeypadNumber value={key} />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
