// src/components/community/CommentItem.tsx
import Avatar from "@/components/common/Avatar";
import TextButton from "@/components/common/TextButton";

interface CommentItemProps {
  name: string;
  date: string;
  content: string;
  isOwner?: boolean;
  onEdit?: () => void;
  onDelete?: () => void;
  onReply?: () => void;
}

// 댓글 한 건을 표시하는 컴포넌트
export default function CommentItem({
  name,
  date,
  content,
  isOwner = false,
  onEdit,
  onDelete,
  onReply,
}: CommentItemProps) {
  return (
    <div className="flex gap-3 py-3">
      <Avatar />

      <div className="flex-1">
        <div className="flex items-baseline gap-2">
          <span className="font-bold">{name}</span>
          <span className="text-sm text-slate-400">{date}</span>
        </div>

        <p className="pt-1 text-slate-700">{content}</p>

        {isOwner ? (
          <div className="flex items-center gap-1 pt-1 text-sm text-slate-400">
            <TextButton onClick={onEdit}>수정</TextButton>
            <span>·</span>
            <TextButton onClick={onDelete}>삭제</TextButton>
          </div>
        ) : (
          <TextButton onClick={onReply} className="pt-1 text-sm text-slate-400">
            답글달기
          </TextButton>
        )}
      </div>
    </div>
  );
}
