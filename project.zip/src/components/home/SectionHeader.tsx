// src/components/home/SectionHeader.tsx
import SectionTitle from "@/components/common/SectionTitle";

interface SectionHeaderProps {
  title: string;
  actionLabel: string;
}

// 섹션 제목과 오른쪽 "더보기" 문구를 나란히 보여주는 컴포넌트
export default function SectionHeader({ title, actionLabel }: SectionHeaderProps) {
  return (
    <div className="flex items-center justify-between">
      <SectionTitle className="py-6 sm:py-8">{title}</SectionTitle>
      <span className="shrink-0 py-6 text-sm font-bold text-primary sm:py-8 sm:text-base lg:text-3xl">
        {actionLabel}
      </span>
    </div>
  );
}
