// src/components/mypage/SettingRow.tsx
interface SettingRowProps {
  label: string;
  actionLabel: string;
  onAction: () => void;
  danger?: boolean;
}

// 라벨과 액션 버튼이 있는 설정 행 컴포넌트
export default function SettingRow({ label, actionLabel, onAction, danger = false }: SettingRowProps) {
  return (
    <div className="flex items-center justify-between gap-4">
      <span className="text-base font-bold text-heading sm:text-lg lg:text-xl">{label}</span>

      <button
        type="button"
        onClick={onAction}
        className={`min-w-28 shrink-0 rounded-2xl bg-primary-soft px-6 py-3 text-base font-bold
          transition-colors hover:bg-primary-soft-hover focus-visible:ring-2 focus-visible:ring-primary
          sm:min-w-36 sm:py-4 sm:text-lg lg:min-w-40 lg:py-5 lg:text-2xl
          ${danger ? "text-danger" : "text-muted"}`}
      >
        {actionLabel}
      </button>
    </div>
  );
}
