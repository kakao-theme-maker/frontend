// src/components/Nav.tsx
import Avatar from "@/components/common/Avatar";
import useMe from "@/hooks/useMe";
import NavButton from "./NavButton";

const NAV_ITEMS = [
  { label: "홈화면", path: "/" },
  { label: "커뮤니티", path: "/community" },
  { label: "테마만들기", path: "/themes/123/customize" },
  { label: "테마관리", path: "/themes/manage" },
  { label: "마이페이지", path: "/mypage" },
] as const;

// 상단 네비게이션 바 컴포넌트
export default function Nav() {
  const { data: me } = useMe();

  return (
    <nav className="fixed inset-x-0 top-0 z-50 h-14 bg-white sm:h-16">
      <div className="mx-auto flex h-full w-full max-w-7xl items-center gap-3 px-4 sm:px-6 lg:px-20">
        <div className="flex shrink-0 justify-start lg:flex-1">
          <span className="text-base font-bold">로고</span>
        </div>

        <div className="min-w-0 flex-1 overflow-x-auto [scrollbar-width:none]">
          <div className="mx-auto flex w-max items-center gap-2 sm:gap-4">
            {NAV_ITEMS.map((item) => (
              <NavButton
                key={item.path}
                label={item.label}
                path={item.path}
              />
            ))}
          </div>
        </div>

        <div className="flex shrink-0 justify-end lg:flex-1">
          <Avatar size="sm" src={me?.profile_image || undefined} alt="내 프로필" />
        </div>
      </div>
    </nav>
  );
}
