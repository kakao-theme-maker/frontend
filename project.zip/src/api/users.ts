// src/api/users.ts
import { api } from './client'
import type { UserResponse } from './types'

// 현재 로그인한 사용자 정보 조회
export const getMe = () =>
  api.get<UserResponse>('/api/users/me').then((r) => r.data)
