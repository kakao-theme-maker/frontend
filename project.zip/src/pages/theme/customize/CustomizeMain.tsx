// src/pages/theme/customize/CustomizeMain.tsx
import { useState } from "react";
import Button from "@/components/common/Button";
import ThemeBasicSettings from "@/components/theme/customize/ThemeBasicSettings";
import ThemePreview from "@/components/theme/customize/ThemePreview";
import PreviewFrame from "@/components/theme/customize/PreviewFrame";
import type { TabKey } from "@/types/customize";
import CustomizeTabs from "@/components/theme/customize/CustomizeTabs";
import TabStrip from "@/components/theme/customize/TabStrip";
import { TABS, EDITOR_MAP, SCREEN_MAP } from "@/config/customizeTabs";
import BottomSheet from "@/components/bottomsheet/BottomSheet";
import PageContainer from "@/components/common/PageContainer";
import PageTitle from "@/components/common/PageTitle";
import SectionTitle from "@/components/common/SectionTitle";
import useMediaQuery from "@/hooks/useMediaQuery";

// 테마 만들기 간편모드 메인 페이지
export default function CustomizeMain() {
  const [activeTab, setActiveTab] = useState<TabKey>("chat");
  const [sheetOpen, setSheetOpen] = useState(false);
  const [basicSheetOpen, setBasicSheetOpen] = useState(false);
  const isDesktop = useMediaQuery("(min-width: 1024px)");

  const ActiveEditor = EDITOR_MAP[activeTab];
  const activeLabel = TABS.find((tab) => tab.key === activeTab)?.label ?? "";

  // 모바일에서 탭 선택 시 바텀시트 열기
  const handleSelectTabMobile = (tab: TabKey) => {
    setActiveTab(tab);
    setSheetOpen(true);
  };

  return (
    <PageContainer>
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center w-full">
        <PageTitle>새 테마 만들기 - 간편모드</PageTitle>
        <div className="sm:ml-auto flex gap-2">
          <Button>임시저장</Button>
          <Button>다운로드</Button>
        </div>
      </div>

      <div className="mt-6">
        {isDesktop ? (
          <ThemeBasicSettings />
        ) : (
          <button
            type="button"
            onClick={() => setBasicSheetOpen(true)}
            className="w-full rounded-xl border border-dashed border-field-border bg-primary-soft px-4 py-3 text-left text-sm font-semibold text-field-label"
          >
            기본설정 (테마 색상·이미지) 수정하기
          </button>
        )}
      </div>

      {isDesktop ? (
        <div className="flex gap-8 mt-6">
          <div className="w-[320px] shrink-0">
            <ThemePreview activeTab={activeTab} />
          </div>
          <CustomizeTabs activeTab={activeTab} onChangeTab={setActiveTab} />
        </div>
      ) : (
        <div className="mt-6">
          <ThemePreview activeTab={activeTab} />

          <TabStrip activeTab={activeTab} onChange={handleSelectTabMobile} className="mt-4" />

          <BottomSheet open={sheetOpen} onClose={() => setSheetOpen(false)} title={activeLabel}>
            <ActiveEditor />
          </BottomSheet>

          <BottomSheet open={basicSheetOpen} onClose={() => setBasicSheetOpen(false)} title="기본설정">
            <ThemeBasicSettings />
          </BottomSheet>
        </div>
      )}

      <div className="mt-10">
        <SectionTitle size="md" className="mb-4">
          전체 화면 미리보기
        </SectionTitle>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-7">
          {TABS.map((tab) => {
            const ScreenPreview = SCREEN_MAP[tab.key];

            return (
              <div
                key={tab.key}
                className="min-w-0  bg-white p-3"
              >
                <h3 className="mb-2 text-xs font-semibold truncate">{tab.label}</h3>
                <PreviewFrame Screen={ScreenPreview} />
              </div>
            );
          })}
        </div>
      </div>
    </PageContainer>
  );
}
