// src/pages/MyPage.tsx
import { useState } from "react";
import Card from "@/components/common/Card";
import PasswordEditForm from "@/components/mypage/PasswordEditForm";
import PillButton from "@/components/mypage/PillButton";
import ProfileEditForm from "@/components/mypage/ProfileEditForm";
import ProfileSummary from "@/components/mypage/ProfileSummary";
import SettingRow from "@/components/mypage/SettingRow";
import type { ProfileFormValues } from "@/types/user";
import PageContainer from "@/components/common/PageContainer";
import PageTitle from "@/components/common/PageTitle";
import QueryStatus from "@/components/common/QueryStatus";
import useMe from "@/hooks/useMe";
import { toUserProfile } from "@/utils/user";

type Mode = "view" | "editProfile" | "editPassword";

const CARD_CLASS = "lg:px-15";

// 마이페이지 (보기/프로필 수정/비밀번호 수정 모드 전환)
export default function MyPage() {
  const [mode, setMode] = useState<Mode>("view");
  const [edits, setEdits] = useState<Partial<ProfileFormValues>>({});
  const { data: me, isLoading, isError } = useMe();

  // 프로필 수정 내용을 반영하고 보기 모드로 복귀
  const handleProfileSubmit = (values: ProfileFormValues) => {
    setEdits(values);
    setMode("view");
  };

  // 비밀번호 변경 후 보기 모드로 복귀
  const handlePasswordSubmit = () => {
    setMode("view");
  };

  // 로그아웃 핸들러 (아직 미구현)
  const handleLogout = () => {
  };

  // 회원탈퇴 확인 후 처리
  const handleWithdraw = () => {
    if (!window.confirm("정말 탈퇴하시겠어요? 이 작업은 되돌릴 수 없어요.")) return;
  };

  if (!me) {
    return (
      <PageContainer>
        <PageTitle>마이페이지</PageTitle>
        <QueryStatus isLoading={isLoading} isError={isError} />
      </PageContainer>
    );
  }

  const user = { ...toUserProfile(me), ...edits };

  return (
    <PageContainer>
      <PageTitle>마이페이지</PageTitle>

      <div className="mt-6 flex flex-col gap-4 sm:mt-8 sm:gap-5">
        <Card className={CARD_CLASS}>
          <ProfileSummary user={user} />
        </Card>

        {mode === "editProfile" ? (
          <>
            <Card className={CARD_CLASS}>
              <ProfileEditForm
                defaultValues={{ name: user.name, bio: user.bio }}
                onSubmit={handleProfileSubmit}
              />
            </Card>
            <Card className={CARD_CLASS}>
              <SettingRow
                label="비밀번호 수정"
                actionLabel="수정하기"
                onAction={() => setMode("editPassword")}
              />
            </Card>
          </>
        ) : (
          <>
            <PillButton onClick={() => setMode("editProfile")}>기본 정보 수정하기</PillButton>
            {mode === "editPassword" && (
              <Card className={CARD_CLASS}>
                <PasswordEditForm onSubmit={handlePasswordSubmit} />
              </Card>
            )}
          </>
        )}

        <Card className={CARD_CLASS}>
          <div className="flex flex-col gap-6 sm:gap-8">
            <SettingRow label="로그아웃" actionLabel="로그아웃" onAction={handleLogout} />
            <SettingRow label="회원탈퇴" actionLabel="회원탈퇴" danger onAction={handleWithdraw} />
          </div>
        </Card>
      </div>
    </PageContainer>
  );
}