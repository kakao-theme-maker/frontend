import { api } from './client'
import type { UserResponse } from './types'

/** 현재 로그인 사용자 (이름, public_user_id 등). 홈 화면 + publicUserId 조회용 */
export const getMe = () =>
  api.get<UserResponse>('/api/users/me').then((r) => r.data)
