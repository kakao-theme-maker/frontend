import { api, buildFormData } from './client'
import type {
  DesignBoardCreate, DesignBoardDetail, DesignBoardListParams, DesignBoardPreview,
} from './types'


export const getDesignBoards = (params?: DesignBoardListParams) =>
  api.get<DesignBoardPreview[]>('/api/design-boards', { params }).then((r) => r.data)

// 디자인 게시글 상세
export const getDesignBoard = (postId: number) =>
  api.get<DesignBoardDetail>(`/api/design-boards/${postId}`).then((r) => r.data)

/** 디자인 게시글 작성 (multipart: board_info(JSON) + preview_image) */
export const createDesignBoard = (boardInfo: DesignBoardCreate, previewImage?: File | null) =>
  api
    .post<DesignBoardDetail>(
      '/api/design-boards',
      buildFormData({ key: 'board_info', value: boardInfo }, { key: 'preview_image', value: previewImage }),
    )
    .then((r) => r.data)
