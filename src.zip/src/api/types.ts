export type Platform = 'ANDROID' | 'IOS'

/** Spring Pageable 공통 쿼리 */
export interface PageParams {
  page?: number
  size?: number
  /** 예: ['createdAt,desc'] — 인기순 표현 방식은 백엔드 확인 필요 */
  sort?: string[]
}

/* ───────── 유저 / 인증 ───────── */
export interface LocalLoginRequest { email: string; password: string }
/** 토큰은 쿠키로도 주입됨. 응답 바디는 쓸 일이 거의 없음 */
export interface UserAuthResponse { accessToken: string; refreshToken: string }

export interface UserResponse {
  name: string
  followers: number
  following: number
  uploads: number
  gender: 'male' | 'female'
  birth: string // YYYY-MM-DD
  user_email: string
  profile_image: string
  profile_image_name: string
  public_user_id: string
  created_at: string
}

/* ───────── 테마 ───────── */
export interface ThemeStyleRequest { colorStyleId: number; color?: string }
export interface ThemeImageRequest { designComponentId?: number; componentTypeId?: number }

/** 테마 생성/수정(임시 저장)/복사 요청 */
export interface ThemeUpsertRequest {
  userEmail: string
  themeName: string
  versionName?: string
  isPublic?: boolean
  styles?: ThemeStyleRequest[]
  images?: ThemeImageRequest[]
}

export interface ThemeStyle {
  colorStyleId: number
  color: string
  // ⚠️ 기획서에는 투명도/플랫폼이 있으나 스웨거에는 없음 → 실제 응답 확인 후 확정
  opacity?: number
  platform?: Platform
}
export interface ThemeImage {
  designComponentId: number
  // ⚠️ 기획서 기준(스웨거 미반영). 실제 응답 확인 후 확정
  imageUrl?: string
  platform?: Platform
  [extra: string]: unknown
}
export interface Theme {
  themeComponentId: number
  userEmail: string
  themeName: string
  versionNumber: string
  versionName: string
  isDone: boolean
  isPublic: boolean
  createdAt: string
  previewImageUrl: string
  styles: ThemeStyle[]
  images: ThemeImage[]
}

/* ───────── 테마 빌드 / 다운로드 (⚠️ 스웨거에 없음 — 기획서 기준) ───────── */
export type BuildId = string | number
export interface ThemeBuildCreateResponse { buildId: BuildId }
export type BuildStatus = 'success' | 'failed' | 'running'
export interface ThemeBuildStatus {
  status: BuildStatus
  /** 완료(success) 시에만 내려옴. 필드명 확인 필요 */
  downloadUrl?: string
}
export interface ThemeDownloadResponse {
  /** 필드명 확인 필요 (문자열 단일 응답일 수도 있음) */
  downloadUrl: string
}

/* ───────── 게시글 공통 ───────── */
export interface TagCreate { tag_name: string }
export interface TagResponse { tag_id: number; tag_name: string }

/** 목록 조회 공통 쿼리 (keyword/typeCode는 기획서 기준, 스웨거에는 아직 없음) */
export interface BoardListParams extends PageParams {
  keyword?: string
}

/* ───────── 테마 게시글 ───────── */
export interface ThemeBoardCreate {
  title: string
  content: string
  themeComponentId?: number
  post_tags?: TagCreate[] // 기획서: 무시해도 됨
  public_flag?: boolean
}
export interface ThemeBoardPreview {
  title: string
  prefers: number
  post_id: number
  theme_component_id: number
  preview_image_url: string
  user_email: string
  created_at: string
}
export interface ThemeBoardDetail {
  title: string
  content: string
  prefers: number
  comments: number
  tags: TagResponse[]
  liked: boolean // 비로그인 시 false
  bookmarked: boolean // 비로그인 시 false
  post_id: number
  theme_component_id: number
  user_email: string
  user_name: string
  created_at: string
  preview_image_url: string[]
  profile_image: string
  /** 작성자 팔로우 여부 — 기획서상 내려오지만 스웨거에는 없음 */
  following?: boolean
}

/* ───────── 디자인 게시글 ───────── */
export interface DesignBoardListParams extends BoardListParams {
  /** 이미지 종류(typeCode) — 기획서 기준, 파라미터명 확인 필요 */
  typeCode?: string
}
export interface DesignBoardCreate {
  title: string
  content: string
  designComponentId: number
  public_flag?: boolean
  post_tags?: TagCreate[]
}
export interface DesignBoardPreview {
  title: string
  prefers: number
  post_id: number
  design_component_id: number
  preview_image_url: string
  user_email: string
  created_at: string
}
export interface DesignBoardDetail {
  title: string
  content: string
  prefers: number
  comments: number
  tags: TagResponse[]
  liked: boolean
  bookmarked: boolean
  post_id: number
  design_component_id: number
  user_email: string
  user_name: string
  created_at: string
  preview_image_url: string[]
  profile_image: string
  following?: boolean
}
