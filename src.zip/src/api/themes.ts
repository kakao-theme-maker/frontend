import { api } from './client'
import type {
  BuildId, PageParams, Platform, Theme, ThemeBuildCreateResponse, ThemeBuildStatus,
  ThemeDownloadResponse, ThemeUpsertRequest,
} from './types'

/** 전체 테마 목록 (홈 - 다른 사람들 테마) */
export const getThemes = (params?: PageParams) =>
  api.get<Theme[]>('/api/themes', { params }).then((r) => r.data)

/**
 * 특정 유저의 테마 목록 (홈 - 내가 최근 만든 테마, 글쓰기 - 내 테마 불러오기)
 * ⚠️ 기획서는 publicUserId, 현재 스웨거는 {userEmail}로 되어 있음 → 백엔드 확인
 */
export const getThemesByUser = (publicUserId: string, params?: PageParams) =>
  api.get<Theme[]>(`/api/themes/user/${encodeURIComponent(publicUserId)}`, { params }).then((r) => r.data)

/** 테마 단건 (제작 화면 진입, 글쓰기 - 테마 이미지 불러오기) */
export const getTheme = (themeId: number) =>
  api.get<Theme>(`/api/themes/${themeId}`).then((r) => r.data)

/** 새 테마 임시 저장 */
export const createTheme = (body: ThemeUpsertRequest) =>
  api.post<Theme>('/api/themes', body).then((r) => r.data)

/**
 * 기존 테마 임시 저장
 * ※ 기획서에는 "PUT /api/users/me"로 적혀 있으나 오타로 보여 스웨거의 PUT /api/themes/{id} 사용. 응답 204
 */
export const updateTheme = (themeId: number, body: ThemeUpsertRequest) =>
  api.put<void>(`/api/themes/${themeId}`, body).then((r) => r.data)

/* ───────── 이하 스웨거에 없음 — 기획서 기준 (경로/필드명 확인 필요) ───────── */

/** 테마 복사 (재다운로드용 소유 목록 저장). 복사만 하며 빌드/다운로드 URL은 별도 */
export const cloneTheme = (body: ThemeUpsertRequest) =>
  api.post<Theme>('/api/themes/clone', body).then((r) => r.data)

/** 1) 빌드 시작 → buildId 반환. 다운로드 URL 조회 전에 먼저 호출해야 함 */
export const buildTheme = (themeId: number) =>
  api.post<ThemeBuildCreateResponse>(`/api/themes/${themeId}/builds`).then((r) => r.data)

/** 2) 빌드 상태 폴링 (running → success | failed). success면 downloadUrl 포함 */
export const getThemeBuild = (buildId: BuildId) =>
  api.get<ThemeBuildStatus>(`/api/theme-builds/${buildId}`).then((r) => r.data)

/**
 * 3) 기존 빌드 결과물의 다운로드 URL 조회. 빌드 결과물이 없으면 404
 * ⚠️ platform을 쿼리로 보낸다고 가정
 */
export const getThemeDownload = (themeId: number, platform: Platform) =>
  api
    .get<ThemeDownloadResponse>(`/api/themes/${themeId}/download`, { params: { platform } })
    .then((r) => r.data)
