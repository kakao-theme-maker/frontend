import { api, buildFormData } from './client'
import type {
  BoardListParams, ThemeBoardCreate, ThemeBoardDetail, ThemeBoardPreview,
} from './types'

/**
 * 테마 게시글 목록 — 커뮤니티 검색/최신순/인기순을 이 하나로 처리 (기획서 기준)
 * ⚠️ keyword 파라미터는 스웨거에 아직 없음
 */
export const getThemeBoards = (params?: BoardListParams) =>
  api.get<ThemeBoardPreview[]>('/api/theme-boards', { params }).then((r) => r.data)

/** 테마 게시글 상세 (팔로우 여부 following 포함) */
export const getThemeBoard = (postId: number) =>
  api.get<ThemeBoardDetail>(`/api/theme-boards/${postId}`).then((r) => r.data)

/** 테마 게시글 작성 (multipart: board_info(JSON) + preview_image) */
export const createThemeBoard = (boardInfo: ThemeBoardCreate, previewImage?: File | null) =>
  api
    .post<ThemeBoardDetail>(
      '/api/theme-boards',
      buildFormData({ key: 'board_info', value: boardInfo }, { key: 'preview_image', value: previewImage }),
    )
    .then((r) => r.data)
