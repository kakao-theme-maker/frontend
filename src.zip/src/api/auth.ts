import { api } from './client'
import type { LocalLoginRequest, UserAuthResponse } from './types'

export const signIn = (body: LocalLoginRequest) =>
  api.post<UserAuthResponse>('/api/auth/local/sign-in', body).then((r) => r.data)

